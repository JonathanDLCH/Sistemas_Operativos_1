/*
Proyecto de Sistemas Operativos 1
Programa cliente que se comunicará a través de sockets de flujo y que simulará un cajero
Debe de poder: consultar, depositar, retirar y salir
Christiam Alberto Parraguirre Lagunes - Jonathan De La Cruz Huerta
28/11/19
*/

#include<sys/types.h>
#include<sys/socket.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<errno.h>
#include<netdb.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<sys/wait.h>
#include<signal.h>

#define PORT 3490
#define MAX 150


struct cliente{
	char nombre[50];
	char direccion[50];
	int cuenta;
	int cantidad;
};

struct datos{
   int op;
   int numCuenta;
   int cantidad;
};

void consultaSaldo(int op,int num_cuenta,int id);
void depositar(int op,int numCuenta,int id,int cantidad);
void retirar(int op,int numCuenta,int id,int cantidad);

void main(int argc, char *argv[]){
	//atributos
	int idSocket,op,num_cuenta,cantidad;
	char cb;
	struct sockaddr_in serv_direc; //direccion servidor

	

	//estructura para direccion de servidor
	serv_direc.sin_family=AF_INET;
	serv_direc.sin_port=htons(PORT);
	serv_direc.sin_addr.s_addr=inet_addr(argv[1]); 
	memset(&(serv_direc.sin_zero),'\0',8);
          
	//desarrollo
	do{
	   printf("\tCajero\n");
	   printf("1.- Consultar saldo\n");
	   printf("2.- Deposito\n");
	   printf("3.- Retiro\n");
	   printf("4.- Salir\n");
	   printf("Introduzca la opción que desea realizar: ");
	   scanf("%d",&op);
	   while(cb=getchar()!='\n' && cb!=EOF);
	   switch(op){
	      case 1:
	         printf("Ingrese numero de cuenta: ");
	         scanf("%d",&num_cuenta);
	         //validacion de socket
	         if((idSocket=socket(AF_INET,SOCK_STREAM,0))==-1){
	   			perror("Socket servidor fallo\n");
	   			exit(1);
	         }
	         //conexion con servidor
	         if(connect(idSocket,(struct sockaddr *)&serv_direc,sizeof(struct sockaddr))){
	    		perror("No conecta\n");
	         }
	         consultaSaldo(op,num_cuenta,idSocket);
	         close(idSocket);
	         break;
	      case 2:
	         printf("\tDeposito\n");
	         printf("Ingrese numero de cuenta: ");
	         scanf("%d",&num_cuenta);
	         printf("Cantidad: ");
	         scanf("%d",&cantidad);
	         //validacion de socket
	         if((idSocket=socket(AF_INET,SOCK_STREAM,0))==-1){
	   			perror("Socket servidor fallo\n");
	   			exit(1);
	         }
	         //conexion con servidor
	         if(connect(idSocket,(struct sockaddr *)&serv_direc,sizeof(struct sockaddr))){
	    		perror("No conecta\n");
	         }
	         depositar(op,num_cuenta,idSocket,cantidad);
	         close(idSocket);
	         break;
	      case 3:
	         printf("Retiro de efectivo\n");
	         printf("Ingrese numero de cuenta: ");
	         scanf("%d",&num_cuenta);
	         printf("Cantidad: ");
	         scanf("%d",&cantidad);
	         //validacion de socket
	         if((idSocket=socket(AF_INET,SOCK_STREAM,0))==-1){
	   			perror("Socket servidor fallo\n");
	   			exit(1);
	         }
	         //conexion con servidor
	         if(connect(idSocket,(struct sockaddr *)&serv_direc,sizeof(struct sockaddr))){
	    		perror("No conecta\n");
	         }
	         retirar(op,num_cuenta,idSocket,cantidad);
	         close(idSocket);
	         break;
	      case 4:
	         printf("\t¡Por su atención gracias!\n");
	         break;
	      default:
	         printf("\tDebe de seleccionar alguna de las opciones\n");
	   }//fin del main
	}while(op!=4);

}//fin del main

void consultaSaldo(int op,int numCuenta,int id){
	int numBytes;
	struct cliente miCliente;
	struct datos miDato;
	printf("\top:%d\nnumCuenta:%d\n",op,numCuenta);
	miDato.numCuenta=numCuenta;
	miDato.op=op;
	miDato.cantidad=0;
	if(send(id,&miDato,sizeof(struct datos),0)==-1){
	   perror("No se envio numero de cuenta\n");
	   exit(1);
	}
	if((numBytes=recv(id,&miCliente,sizeof(struct cliente),0))==-1){
		perror("Fallo con servidor\n");
	}
	printf("Datos del cliente\n");
	printf("Nombre: %s",miCliente.nombre);
	printf("Cuenta: %d\n",miCliente.cuenta);
	printf("Cantidad: %d\n",miCliente.cantidad);
	printf("Direccion: %s",miCliente.direccion);
}

void depositar(int op,int numCuenta,int id,int cantidad){
	struct datos miDato;
	struct cliente miCliente;
	printf("Cantidad a enviar: %d",cantidad);
	int numBytes;
	miDato.op=op;
	miDato.numCuenta=numCuenta;
	miDato.cantidad=cantidad;
	if(send(id,&miDato,sizeof(struct datos),0)==-1){
		perror("No se podra depositar\n");
		exit(1);
	}
	if((numBytes=recv(id,&miCliente,sizeof(struct cliente),0))==-1){
		perror("No recibio ticket de deposito\n");
		exit(1);
	}
	printf("\tTicket\n");
	printf("Nombre: %s",miCliente.nombre);
	printf("Cuenta: %d\n",miCliente.cuenta);
	printf("Cantidad: %d\n",miCliente.cantidad);
	printf("Direccion: %s",miCliente.direccion);
}

void retirar(int op,int numCuenta,int id,int cantidad){
	struct datos miDato;
	struct cliente miCliente;
	int numBytes;
	miDato.op=op;
	miDato.numCuenta=numCuenta;
	miDato.cantidad=cantidad;
	if(send(id,&miDato,sizeof(struct datos),0)==-1){
		perror("No se podra depositar\n");
		exit(1);
	}
	if((numBytes=recv(id,&miCliente,sizeof(struct cliente),0))==-1){
		perror("No recibio ticket de retiro\n");
		exit(1);
	}
	printf("\tTicket\n");
	printf("Nombre: %s",miCliente.nombre);
	printf("Cuenta: %d\n",miCliente.cuenta);
	printf("Cantidad: %d\n",miCliente.cantidad);
	printf("Direccion: %s",miCliente.direccion);
}