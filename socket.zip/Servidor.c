/*
Programa que simulara servidor

Proyecto Sistemas Operativos 1
Christiam Alberto Parraguirre Lagunes
Jonathan De la Cruz Huerta
28/11/19 
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include<fcntl.h>

#define MYPORT 3490    // Puerto al que conectarán los usuarios
#define BACKLOG 10     // Cuántas conexiones pendientes se mantienen en cola
#define MAXUSERS 10    // Numero maximo de usuarios
#define dir "BD.dat"   // Direccion del archivo

int Consultar(int cuenta,int new_fd);
int Depositar(int cuenta, int cantidad,int new_fd);
int Retirar(int cuenta,int cantidad,int new_fd);
void Error(int new_fd);

int contador=0;

struct cliente{
   char nombre[50];
   char direccion[50];
   int cuenta;
   int cantidad;
};
struct cliente Clientes[MAXUSERS];

struct dato{
	int op;
	int cuenta;
	int cantidad;
};

void conBD();
void resBD();

int main(int argc,char *argv[]){
	int sockfd, new_fd;  // Escuchar sobre sockfd, nuevas conexiones sobre new_fd
	struct sockaddr_in my_addr;    // información sobre mi dirección
	struct sockaddr_in their_addr; // información sobre la dirección del cliente
	struct dato Datos;
	int sin_size;

	conBD();

	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) { //Obtenemos el id sel socket
		perror("socket");
		exit(1);
	}

	my_addr.sin_family = AF_INET;         // Ordenación de bytes de la máquina
	my_addr.sin_port = htons(MYPORT);     // short, Ordenación de bytes de la red
	my_addr.sin_addr.s_addr = INADDR_ANY; // Rellenar con mi dirección IP
	memset(&(my_addr.sin_zero), '\0', 8); // Poner a cero el resto de la estructura

	//Asignamos un socket a un puerto
	if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1){
		perror("bind");
		exit(1);
	}
	if (listen(sockfd, BACKLOG) == -1){
		perror("listen");
		exit(1);
	}

	while(1){
		system("clear");
		printf("Esperando peticion...\n");
		sin_size = sizeof(struct sockaddr_in);
		if ((new_fd = accept(sockfd, (struct sockaddr *)&their_addr, &sin_size)) == -1){
			//Escucha y permite que algún cliente se conecte tras utilizar la función connect();
			perror("accept");
			continue;
		}
		printf("server: got connection from %s\n",inet_ntoa(their_addr.sin_addr));

		if(recv(new_fd, &Datos, sizeof(struct dato), 0) == -1){
			perror("recv");
			exit(1);
		}

		printf("%d\n",Datos.cuenta);
		printf("%d\n",Datos.op );

		switch(Datos.op){
			case 1: 
					if(Consultar(Datos.cuenta,new_fd)==0){
						printf("No se encontro la cuenta.\n");
						Error(new_fd);
					}
					//resBD();
				break;
			case 2: 
					if(Depositar(Datos.cuenta,Datos.cantidad,new_fd)==0){
						printf("No se encontro la cuenta.\n");
						Error(new_fd);
					}
					resBD();
				break;
			case 3: 
					if(Retirar(Datos.cuenta,Datos.cantidad,new_fd)==0){
						printf("No se encontro la cuenta.\n");
						Error(new_fd);
					}
					resBD();
				break;
			default: printf("Opcion invalida\n");
		}
		close(new_fd);
	}
return 0;
}

void conBD(){
	int df,i=0;
	if((df=open(dir,0))==-1){
		perror("Error al abrir el archivo");
		exit(-1);
	}
	while(read(df,&Clientes[i],sizeof(struct cliente))>0){
		/*printf("Nombre: %s",Clientes[i].nombre);
		printf("Cuenta: %d",Clientes[i].cuenta);
		printf("Direccion: %s",Clientes[i].direccion);
		printf("Cantidad: %d",Clientes[i].cantidad);*/
		i++;
	}
	contador=i;
	close(df);
}

void resBD(){
	int df,bytes;
	if((df=open(dir,1))==-1){
		perror("Error al abrir el archivo");
		exit(-1);
	}
	for (int i=0; i<=contador;i++){
		printf("Cantidad: %d",Clientes[i].cantidad);
		if(write(df,&Clientes[i],sizeof(struct cliente))==-1){
			perror("Error en la escritura.");
		}
	}
	close(df);
}

int Consultar(int cuenta,int new_fd){
	struct cliente micliente;
	int df,flg=0;
	df=open(dir,0);

	while(read(df,&micliente,sizeof(struct cliente))>0){
		if(micliente.cuenta==cuenta){
			if (send(new_fd,&micliente, sizeof(struct cliente), 0) == -1){
				perror("send");
			}else{
				flg=1;
			}
		}
	}
	close(df);
	return flg;
}

int Depositar(int cuenta, int cantidad,int new_fd){
	struct cliente micliente;
	int df,flg=0,dep;
	df=open(dir,0);

	while(read(df,&micliente,sizeof(struct cliente))>0){
		if(micliente.cuenta==cuenta){
			
			dep=micliente.cantidad+cantidad;
			micliente.cantidad=dep;

			if (send(new_fd,&micliente, sizeof(struct cliente), 0) == -1){
				perror("send");
			}else{
				flg=1;
			}
			for(int i=0;i<=contador;i++){
				if(Clientes[i].cuenta==micliente.cuenta){
					Clientes[i]=micliente;
				}
			}
		}
	}
	close(df);
	return flg;
}

int Retirar(int cuenta,int cantidad,int new_fd){
	struct cliente micliente;
	int df,flg=0,dep;
	df=open(dir,0);

	while(read(df,&micliente,sizeof(struct cliente))>0){
		if(micliente.cuenta==cuenta){
			if(micliente.cantidad>=cantidad){
				dep=micliente.cantidad-cantidad;
				micliente.cantidad=dep;
				if (send(new_fd,&micliente, sizeof(struct cliente), 0) == -1){
					perror("send");
				}else{
					flg=1;
				}
				for(int i=0;i<=contador;i++){
					if(Clientes[i].cuenta==micliente.cuenta){
						Clientes[i]=micliente;
					}
				}
			}else{
				Error(new_fd);
			}
		}
	}
	close(df);
	return flg;
}

void Error(int new_fd){
	struct cliente Eclien;
	Eclien.cuenta=-1;
	Eclien.cantidad=0;
	if (send(new_fd,&Eclien, sizeof(struct cliente), 0) == -1){
		perror("send");
	}
	printf("Error\n");
}

/*
int socket(int domain, int type, int protocol);
int bind(int sockfd, struct sockaddr *my_addr,int addrlen);


*/